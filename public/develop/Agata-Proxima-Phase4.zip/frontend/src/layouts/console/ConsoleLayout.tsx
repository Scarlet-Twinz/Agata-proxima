import { useEffect, useMemo, useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  ChevronDown,
  CircleHelp,
  CreditCard,
  Database,
  FileSearch,
  Gauge,
  KeyRound,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  Rocket,
  Search,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Users,
  X,
  Bell,
} from "lucide-react";
import { getSession, logout, type Session } from "../../api/auth";
import { api } from "../../api/client";
import { AgataLogo } from "../../components/brand/AgataLogo";

const primaryNavigation = [
  { label: "Overview", href: "/app", icon: Gauge },
  { label: "Security", href: "/app/security", icon: ShieldCheck },
  { label: "Tenants", href: "/app/tenants", icon: Users },
  { label: "Policies", href: "/app/policies", icon: SlidersHorizontal },
  { label: "Nodes", href: "/app/nodes", icon: Database },
  { label: "Deployments", href: "/app/deployments", icon: Rocket },
  { label: "Verification", href: "/app/verification", icon: ShieldCheck },
  { label: "Audit", href: "/app/audit", icon: FileSearch },
  { label: "Team", href: "/app/team", icon: Users },
  { label: "Billing", href: "/app/billing", icon: CreditCard },
];

const platformNavigation = [
  { label: "Developer", href: "/app/developer", icon: KeyRound },
  { label: "Settings", href: "/app/settings", icon: Settings },
  { label: "Support", href: "/app/support", icon: CircleHelp },
];

const searchNavigation = [
  ...primaryNavigation,
  ...platformNavigation,
  { label: "Billing usage", href: "/app/billing/usage", icon: CreditCard },
  { label: "Billing plans", href: "/app/billing/plans", icon: CreditCard },
  { label: "Billing invoices", href: "/app/billing/invoices", icon: CreditCard },
  { label: "Tenant isolation", href: "/app/security/tenant-isolation", icon: ShieldCheck },
  { label: "Security events", href: "/app/security/events", icon: FileSearch },
  { label: "Developer API keys", href: "/app/developer/api-keys", icon: KeyRound },
  { label: "Developer tenant context", href: "/app/developer/tenant-context", icon: KeyRound },
  { label: "Developer webhooks", href: "/app/developer/webhooks", icon: KeyRound },
  { label: "Developer API reference", href: "/app/developer/api-reference", icon: KeyRound },
  { label: "Settings authentication", href: "/app/settings/authentication", icon: Settings },
  { label: "Settings identity", href: "/app/settings/identity", icon: Settings },
  { label: "Settings security", href: "/app/settings/security", icon: Settings },
];

export function ConsoleLayout() {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(() => {
    return localStorage.getItem("agata.console.sidebar") === "collapsed";
  });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [environmentOpen, setEnvironmentOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [session, setSession] = useState<Session | null>(null);
  const [sessionLoading, setSessionLoading] = useState(true);
  const [organizationName, setOrganizationName] = useState("Workspace");
  const [accountDisplayName, setAccountDisplayName] = useState("Account");
  const [accountEmail, setAccountEmail] = useState("");
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  useEffect(() => {
    const savedTheme = localStorage.getItem("agata.theme");
    if (savedTheme === "dark" || savedTheme === "light") {
      document.documentElement.dataset.theme = savedTheme;
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(
      "agata.console.sidebar",
      collapsed ? "collapsed" : "expanded",
    );
  }, [collapsed]);

  useEffect(() => {
    let active = true;
    async function initializeConsole() {
      try {
        const current = await getSession();
        if (!active) return;
        if (!current) {
          setSession(null);
          navigate("/login", { replace: true, state: { from: window.location.pathname } });
          return;
        }
        setSession(current);
        if (current.csrf_token) sessionStorage.setItem("proxima_csrf", current.csrf_token);

        void api.get<{organization:{name:string;slug:string};organizations:unknown[];user:{display_name?:string;email?:string}}>("/api/v1/settings")
          .then((settings) => {
            if (!active) return;
            setOrganizationName(settings.organization.name || "Workspace");
            setAccountDisplayName(settings.user.display_name || "Account");
            setAccountEmail(settings.user.email || "");
          })
          .catch(() => undefined);
        void api.get<{notifications:{read:boolean}[]}>("/api/v1/notifications")
          .then((result) => {
            if (active) setUnreadNotifications(result.notifications.filter((item) => !item.read).length);
          })
          .catch(() => undefined);
      } catch {
        if (active) {
          setSession(null);
          navigate("/login", { replace: true, state: { from: window.location.pathname } });
        }
      } finally {
        if (active) setSessionLoading(false);
      }
    }
    void initializeConsole();
    return () => {
      active = false;
    };
  }, [navigate]);

  async function handleLogout() {
    await logout();
    setAccountOpen(false);
    navigate("/login", { replace: true });
  }

  const accountLabel = accountDisplayName || "Account";
  const accountInitial = accountLabel.trim().slice(0, 1).toUpperCase() || "A";
  const organizationInitial = organizationName.trim().slice(0, 1).toUpperCase() || "W";

  const searchResults = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    if (!query) return searchNavigation.slice(0, 8);

    return searchNavigation.filter((item) =>
      item.label.toLowerCase().includes(query),
    );
  }, [searchQuery]);

  function openSearch() {
    setSearchOpen(true);
    setSearchQuery("");
    setEnvironmentOpen(false);
  }

  function closeSearch() {
    setSearchOpen(false);
    setSearchQuery("");
  }

  useEffect(() => {
    function handleUnreadNotificationsChange(event: Event) {
      const detail = (event as CustomEvent<{ unread?: number }>).detail;
      if (typeof detail?.unread === "number" && Number.isFinite(detail.unread)) {
        setUnreadNotifications(Math.max(0, Math.floor(detail.unread)));
      }
    }
    window.addEventListener("agata:notifications-unread-change", handleUnreadNotificationsChange);
    return () => window.removeEventListener("agata:notifications-unread-change", handleUnreadNotificationsChange);
  }, []);

  useEffect(() => {
    function handleSessionExpired() {
      setAccountOpen(false);
      navigate("/login", { replace: true, state: { from: window.location.pathname, sessionExpired: true } });
    }
    window.addEventListener("agata:session-expired", handleSessionExpired);
    return () => window.removeEventListener("agata:session-expired", handleSessionExpired);
  }, [navigate]);

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        openSearch();
      }

      if (searchOpen && event.key === "Escape") {
        closeSearch();
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [searchOpen]);

  if (sessionLoading) {
    return <div className="console-root"><main className="console-main"><div className="surface empty-state"><strong>Checking your session…</strong><span>Opening the command center securely.</span></div></main></div>;
  }
  if (!session) return null;

  return (
    <div
      className={[
        "console-root",
        collapsed ? "console-root--collapsed" : "",
      ].join(" ")}
    >
      {mobileOpen && (
        <button
          className="console-mobile-backdrop"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={[
          "console-sidebar",
          mobileOpen ? "console-sidebar--mobile-open" : "",
        ].join(" ")}
      >
        <div className="console-brand">
          <AgataLogo compact />

          {!collapsed && (
            <div className="console-brand-copy">
              <strong>AGATA PROXIMA</strong>
              <span>Control Plane</span>
            </div>
          )}

          <button
            className="console-icon-button console-sidebar-collapse"
            onClick={() => setCollapsed((value) => !value)}
            title={collapsed ? "Expand navigation" : "Collapse navigation"}
            aria-label={collapsed ? "Expand navigation" : "Collapse navigation"}
          >
            {collapsed ? (
              <PanelLeftOpen size={17} />
            ) : (
              <PanelLeftClose size={17} />
            )}
          </button>

          <button
            className="console-icon-button console-mobile-close"
            onClick={() => setMobileOpen(false)}
            aria-label="Close navigation"
          >
            <X size={18} />
          </button>
        </div>

        <button className="workspace-switcher" type="button" onClick={() => navigate("/app/settings")}>
          <span className="workspace-symbol">{organizationInitial}</span>

          {!collapsed && (
            <span className="workspace-copy">
              <strong>{organizationName}</strong>
              <small>Production</small>
            </span>
          )}

          {!collapsed && <ChevronDown size={16} />}
        </button>

        <nav className="console-nav">
          <div className="console-nav-group">
            {!collapsed && <span className="console-nav-label">CONTROL</span>}

            {primaryNavigation.map((item) => {
              const Icon = item.icon;

              return (
                <NavLink
                  key={item.href}
                  to={item.href}
                  end={item.href === "/app"}
                  title={collapsed ? item.label : undefined}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `console-nav-link ${isActive ? "is-active" : ""}`
                  }
                >
                  <Icon size={19} strokeWidth={1.8} />
                  {!collapsed && <span>{item.label}</span>}
                </NavLink>
              );
            })}
          </div>

          <div className="console-nav-group">
            {!collapsed && <span className="console-nav-label">PLATFORM</span>}

            {platformNavigation.map((item) => {
              const Icon = item.icon;

              return (
                <NavLink
                  key={item.href}
                  to={item.href}
                  title={collapsed ? item.label : undefined}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `console-nav-link ${isActive ? "is-active" : ""}`
                  }
                >
                  <Icon size={19} strokeWidth={1.8} />
                  {!collapsed && <span>{item.label}</span>}
                </NavLink>
              );
            })}
          </div>
        </nav>
      </aside>

      {searchOpen && (
        <div className="console-search-backdrop" onMouseDown={closeSearch}>
          <div
            className="console-search-dialog"
            role="dialog"
            aria-modal="true"
            aria-label="Search console"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="console-search-input-wrap">
              <Search size={18} />
              <input
                autoFocus
                value={searchQuery}
                onChange={(event) => setSearchQuery(event.target.value)}
                placeholder="Search the control plane..."
                aria-label="Search the control plane"
              />
              <kbd>Esc</kbd>
            </div>

            <div className="console-search-results">
              {searchResults.length ? (
                searchResults.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      className="console-search-result"
                      type="button"
                      key={item.href}
                      onClick={() => {
                        closeSearch();
                        navigate(item.href);
                      }}
                    >
                      <Icon size={17} />
                      <span>{item.label}</span>
                    </button>
                  );
                })
              ) : (
                <div className="console-search-empty">
                  No console surface matches “{searchQuery}”.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <main className="console-main">
        <header className="console-topbar">
          <div className="console-topbar-left">
            <button
              className="console-icon-button console-mobile-menu"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation"
            >
              <Menu size={20} />
            </button>

            <div className="console-breadcrumb">
              <span>Agata Proxima</span>
              <span>/</span>
              <strong>{organizationName}</strong>
              <span>/</span>
              <span>Production</span>
            </div>
          </div>

          <div className="console-topbar-actions">
            <div className="console-environment-wrap">
              <button
                className="environment-button"
                type="button"
                aria-expanded={environmentOpen}
                onClick={() => {
                  setEnvironmentOpen((value) => !value);
                  setAccountOpen(false);
                }}
              >
                <span className="environment-dot" />
                Production
                <ChevronDown size={15} />
              </button>

              {environmentOpen && (
                <div className="console-environment-menu">
                  <button
                    className="console-environment-option is-selected"
                    type="button"
                    onClick={() => setEnvironmentOpen(false)}
                  >
                    <span>
                      <strong>Production</strong>
                      <small>Active environment</small>
                    </span>
                    <span className="environment-check">✓</span>
                  </button>
                  <button
                    className="console-environment-settings"
                    type="button"
                    onClick={() => {
                      setEnvironmentOpen(false);
                      navigate("/app/settings");
                    }}
                  >
                    Manage environments
                  </button>
                </div>
              )}
            </div>

            <button
              className="command-button"
              type="button"
              onClick={openSearch}
              aria-haspopup="dialog"
              aria-expanded={searchOpen}
            >
              <Search size={17} />
              <span>Search</span>
              <kbd>⌘K</kbd>
            </button>
            <button className="console-icon-button notification-button" type="button" onClick={() => navigate("/app/notifications")} aria-label="Open notifications" title="Notifications">
              <Bell size={18} />
              {unreadNotifications > 0 && <span className="notification-badge">{unreadNotifications > 99 ? "99+" : unreadNotifications}</span>}
            </button>

            <div className="console-account-wrap">
              <button
                className="console-account"
                type="button"
                aria-expanded={accountOpen}
                onClick={() => setAccountOpen((value) => !value)}
              >
                <span className="account-avatar">{accountInitial}</span>
                <span>{accountLabel}</span>
                <ChevronDown size={15} />
              </button>

              {accountOpen && (
                <div className="console-account-menu">
                  <div className="console-account-meta">
                    <strong>{accountLabel}</strong>
                    <span>{accountEmail || session?.role || "Account"}</span>
                  </div>
                  <button type="button" onClick={handleLogout}>
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        <section className="console-content">
          <Outlet />
        </section>
      </main>
    </div>
  );
}
