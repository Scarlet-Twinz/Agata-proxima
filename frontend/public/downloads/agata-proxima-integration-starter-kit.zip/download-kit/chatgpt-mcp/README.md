# ChatGPT / MCP connector design

This folder is the connector design checklist, not a running MCP server.

Recommended tools are organization-scoped, read-only operations first: list tenants, inspect policy/deployment summaries, read verification outcomes and search audit events. A deployed server must authenticate with a dedicated credential or OAuth flow, authorize every call, validate arguments, redact sensitive output, rate-limit requests and audit mutations. Require explicit confirmation for state-changing tools. Test revoked credentials and cross-organization denial before connecting the endpoint to ChatGPT.
