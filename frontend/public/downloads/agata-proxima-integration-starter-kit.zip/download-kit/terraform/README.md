# Terraform integration notes

This folder is a design and acceptance checklist, not an Agata Terraform provider.

Before publishing a provider, implement and test resource schemas and CRUD/import/drift behavior against the actual API. Protect Terraform state, keep credentials in CI secrets, and test organization isolation and non-destructive deletion semantics. Do not invent a provider namespace or `required_providers` block until a real registry artifact exists.
